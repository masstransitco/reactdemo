import React from "react";

function About() {
  return (
    <div>
      <h1>About Us</h1>
      <p>This page provides information about the application.</p>
    </div>
  );
}

export default About;
